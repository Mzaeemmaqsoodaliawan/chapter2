#include <iostream>
#include <cmath>  
#include <iomanip> 

using namespace std;

int main() {
    
    const double CARTON_CAPACITY = 3.78;     // Liters per carton
    const double COST_PER_LITER = 0.38;      // Cost in dollars
    const double PROFIT_PER_CARTON = 0.27;   // Profit in dollars

    double milkProduced;
    cout << "Enter the total amount of milk produced (in liters): ";
    cin >> milkProduced;

    // b. Calculate number of cartons needed (rounded up)
    int cartonsNeeded = ceil(milkProduced / CARTON_CAPACITY);

    // c. Calculate cost of producing milk
    double productionCost = milkProduced * COST_PER_LITER;

    // d. Calculate profit
    double totalProfit = cartonsNeeded * PROFIT_PER_CARTON;

    cout << fixed << setprecision(2); // Format output to 2 decimal places
    cout << "\nMilk cartons needed: " << cartonsNeeded << endl;
    cout << "Cost of producing milk: $" << productionCost << endl;
    cout << "Profit from milk: $" << totalProfit << endl;

    return 0;
}