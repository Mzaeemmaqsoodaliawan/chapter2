#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const double PI = 3.141593; // Named constant for π
    double radius, area, circumference;

    
    cout << "Enter the radius of the circle: ";
    cin >> radius;

    
    area = PI * radius * radius;
    circumference = 2 * PI * radius;

    cout << fixed << setprecision(4);
    cout << "\nRadius of Circle: " << radius << endl;
    cout << "Area of Circle: " << area << endl;
    cout << "Circumference of Circle: " << circumference << endl;

    return 0;
}