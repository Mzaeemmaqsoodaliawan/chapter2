#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
    const double k = 6.67e-8;  // gravitational constant in dyn.cm^2/g^2
    double M1, M2, d;

    // Input
    cout << "Enter mass of first body (in grams): ";
    cin >> M1;
    cout << "Enter mass of second body (in grams): ";
    cin >> M2;
    cout << "Enter distance between the bodies (in cm): ";
    cin >> d;

    // Force calculation
    double F = k * (M1 * M2) / (d*d);
    cout << fixed << setprecision(10);
    cout << "\nThe gravitational force between the bodies is: " 
         << F << " dynes." << endl;

    return 0;
}