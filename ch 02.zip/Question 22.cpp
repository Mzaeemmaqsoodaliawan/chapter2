#include <iostream>
using namespace std;

int main() {
    const double METRIC_TON = 2205; 
    double bagCapacity, bagsNeeded;
    cout << "Enter the capacity of one bag (in pounds): ";
    cin >> bagCapacity;

    // Calculate number of bags required
    bagsNeeded = METRIC_TON / bagCapacity;
    cout << "Number of bags needed to store one metric ton of rice = "
         << bagsNeeded << endl;
         return 0;
}