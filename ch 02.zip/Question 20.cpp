#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double fixedCommission, carCost;
    cout << "Enter the salesperson's fixed commission: $";
    cin >> fixedCommission;
    cout << "Enter the purchasing cost of the car: $";
    cin >> carCost;

    // Selling price range
    double minSellingPrice = carCost + 200;
    double maxSellingPrice = carCost + 2000;

    // Commission calculations
    double commissionMin = fixedCommission + 0.30 * (minSellingPrice - carCost);
    double commissionMax = fixedCommission + 0.30 * (maxSellingPrice - carCost);
    cout << fixed << setprecision(2);
    cout << "\nMinimum selling price: $" << minSellingPrice;
    cout << "\nMaximum selling price: $" << maxSellingPrice;
    cout << "\nCommission at minimum selling price: $" << commissionMin;
    cout << "\nCommission at maximum selling price: $" << commissionMax << endl;

    return 0;
}