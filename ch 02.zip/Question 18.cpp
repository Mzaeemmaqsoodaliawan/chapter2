#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double payRate, hoursPerWeek;
    const int weeks = 5;

    
    cout << "Enter hourly pay rate: ";
    cin >> payRate;
    cout << "Enter number of hours worked per week: ";
    cin >> hoursPerWeek;

    // 1. Gross income before tax
    double incomeBeforeTax = payRate * hoursPerWeek * weeks;

    // 2. After tax (14%)
    double incomeAfterTax = incomeBeforeTax * (1 - 0.14);

    // 3. Clothes (10%)
    double clothes = incomeAfterTax * 0.10;

    // 4. School supplies (1%)
    double schoolSupplies = incomeAfterTax * 0.01;

    // 5. Remaining after clothes & supplies
    double remaining = incomeAfterTax - (clothes + schoolSupplies);

    // 6. Savings bonds (25% of remaining)
    double savingsBonds = remaining * 0.25;

    // 7. Parents spend $0.50 per $1 on bonds
    double parentsBonds = savingsBonds * 0.50;

    
    cout << fixed << setprecision(2);
    cout << "\nIncome before tax: $" << incomeBeforeTax;
    cout << "\nIncome after tax: $" << incomeAfterTax;
    cout << "\nMoney spent on clothes: $" << clothes;
    cout << "\nMoney spent on school supplies: $" << schoolSupplies;
    cout << "\nMoney spent on savings bonds: $" << savingsBonds;
    cout << "\nParents spend on savings bonds: $" << parentsBonds << endl;

    return 0;
}