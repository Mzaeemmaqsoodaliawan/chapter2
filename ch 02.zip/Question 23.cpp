#include <iostream>
using namespace std;

int main() {
    const double SERVICE_RATE = 0.015;  

    int shares;
    double purchasePrice, sellingPrice;
    double amountInvested, amountReceived, buyCharge, sellCharge, totalServiceCharges, profitLoss;

    cout << "Enter number of shares sold: ";
    cin >> shares;
    cout << "Enter purchase price per share: ";
    cin >> purchasePrice;
    cout << "Enter selling price per share: ";
    cin >> sellingPrice;

    
    amountInvested = shares * purchasePrice;
    amountReceived = shares * sellingPrice;

    buyCharge = amountInvested * SERVICE_RATE;
    sellCharge = amountReceived * SERVICE_RATE;
    totalServiceCharges = buyCharge + sellCharge;

    profitLoss = (amountReceived - sellCharge) - (amountInvested + buyCharge);
    cout << "\n--- Stock Transaction Report ---" << endl;
    cout << "Amount invested: $" << amountInvested << endl;
    cout << "Total service charges: $" << totalServiceCharges << endl;
    if (profitLoss > 0)
        cout << "Amount gained: $" << profitLoss << endl;
    else
        cout << "Amount lost: $" << -profitLoss << endl;
    cout << "Amount received after selling: $" << (amountReceived - sellCharge) << endl;

    return 0;
}