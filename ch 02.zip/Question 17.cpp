#include <iostream>
#include <cmath>     // For ceil function
#include <iomanip>   // For formatting output

using namespace std;

int main() {
    const double CARTON_CAPACITY = 3.78;  

    
    double milkProduced;
    double costPerLiter;
    double profitPerCarton;

    // a. Prompt user for total milk produced
    cout << "Enter the total amount of milk produced (in liters): ";
    cin >> milkProduced;

    // Prompt user for cost per liter
    cout << "Enter the cost of producing one liter of milk: $";
    cin >> costPerLiter;

    // Prompt user for profit per carton
    cout << "Enter the profit on each carton of milk: $";
    cin >> profitPerCarton;

    // b. Calculate number of cartons needed (rounded up)
    int cartonsNeeded = ceil(milkProduced / CARTON_CAPACITY);

    // c. Calculate cost of producing milk
    double productionCost = milkProduced * costPerLiter;

    // d. Calculate profit
    double totalProfit = cartonsNeeded * profitPerCarton;

    
    cout << fixed << setprecision(2); // Format output to 2 decimal places
    cout << "\nMilk cartons needed: " << cartonsNeeded << endl;
    cout << "Cost of producing milk: $" << productionCost << endl;
    cout << "Profit from milk: $" << totalProfit << endl;

    return 0;
}