#include <iostream>
using namespace std;

int main() {
    double capacity, milesPerGallon, totalMiles;
    cout << "Enter the fuel tank capacity in gallons: ";
    cin >> capacity;
    cout << "Enter the miles per gallon the autobike can be driven: ";
    cin >> milesPerGallon;
    totalMiles = capacity * milesPerGallon;
    cout << "The autobike can be driven " << totalMiles << " miles without refueling." << endl;

    return 0;
}