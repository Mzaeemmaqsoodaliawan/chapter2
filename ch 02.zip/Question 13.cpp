#include <iostream>
using namespace std;

int main() {
    double originalPrice, markupPercent, taxRate;
    double sellingPrice, salesTax, finalPrice;
    cout << "Enter the original price of the item: ";
    cin >> originalPrice;

    cout << "Enter the percentage of markup: ";
    cin >> markupPercent;

    cout << "Enter the sales tax rate: ";
    cin >> taxRate;
    sellingPrice = originalPrice + (originalPrice * markupPercent / 100);
    salesTax = sellingPrice * taxRate / 100;
    finalPrice = sellingPrice + salesTax;
    cout << "\nOriginal Price: $" << originalPrice << endl;
    cout << "Markup Percentage: " << markupPercent << "%" << endl;
    cout << "Store's Selling Price: $" << sellingPrice << endl;
    cout << "Sales Tax Rate: " << taxRate << "%" << endl;
    cout << "Sales Tax: $" << salesTax << endl;
    cout << "Final Price of the Item: $" << finalPrice << endl;

    return 0;
}