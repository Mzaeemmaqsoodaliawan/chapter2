#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double driveSize, actualSize;

    cout << "Enter the size of the hard drive (in GB) as specified by the manufacturer: ";
    cin >> driveSize;

    actualSize = (driveSize * 1000000000) / 1073741824;

    cout << fixed << setprecision(2);
    cout << "\nManufacturer's specified size: " << driveSize << " GB" << endl;
    cout << "Actual storage capacity: " << actualSize << " GB" << endl;

    return 0;
}