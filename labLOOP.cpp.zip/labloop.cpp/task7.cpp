#include<iostream>
using namespace std;
int main()
{
int fibonacci;
cout<<"enter the number:";
cin>>fibonacci;
for(int i=fibonacci-1;i>=0;i--)
cout<<i<<endl;
return 0;
}