#include<iostream>
using namespace std;
int main()
{
    int sum=0,num;
    cout<<"enter the number:";
    cin>>num;
    cout<<" digit are : "<<endl;
    while(num>0){
        int digit=num%10;
        sum=sum+digit;
        num=num/10;
    }
    cout<<"sum:"<<sum<<endl;
    return 0;
}