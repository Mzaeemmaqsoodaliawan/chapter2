#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    int n;
    cout<<"enter number count:";
    cin>>n;
    int p1=0,p2=0,p3=0,p4=0,p5=0;
    for(int i=0;i<n;++i){
        int num;
        cout<<"enter a number:";
        cin>>num;
    if(num<200)p1++;
    else  if(num<400)p2++;
    else if(num<600)p3++;
    else if(num<800)p4++;
     else p5++;
}
  double percent1=(double)p1/n*100;
  double percent2=(double)p2/n*100;
  double percent3=(double)p3/n*100;
  double percent4=(double)p4/n*100;
  double percent5=(double)p5/n*100;
  cout<< fixed <<setprecision(2);
  cout<<percent1<<"%"<<endl;
  cout<<percent2<<"%"<<endl;
  cout<<percent3<<"%"<<endl;
  cout<<percent4<<"%"<<endl;
  cout<<percent5<<"%"<<endl;
  return 0;
}
