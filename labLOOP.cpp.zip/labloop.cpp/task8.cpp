#include<iostream>
using namespace std;
int main()
{
    int num,count=0;
    cout<<"enter a number:";
    cin>>num;
    int z=num;
    if(z==0)
     count=1;
     else{
        if(z<0)
        z=-z;
        while(z!=0)
        { 
            z/=10;
            count++;
        } 
        cout<<"Total number of digits are:"<<count<<endl;
        return 0;
     }
    }