#include<iostream>
using namespace std;
int main()
{
    int year,age=18;
    double money,spend=0;
    cout<<"Enter Money:";
    cin>>money;
    cout<<"Enter year:";
    cin>>year;
    for(int i=1800;i<=year;i++)
    {
        if(i%2==0){
            spend+=12000;
        }else
        {
            spend+=12000+50*age;
        }
        age++;
    }
    if(money>=spend)
    {
        cout<<"yes!He will live a carefree life and will have "  <<money-spend<<" dollars left "<<endl;
    } else{
     cout<<"He wil need "<<spend-money<<"dollar to survive"<<endl;
    }
    return 0;
}