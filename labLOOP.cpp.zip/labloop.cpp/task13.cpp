#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
int age,toys=0;
double price_wash_machine,toy_price;
cout<<"enter lilly's  age :";
cin>>age;
cout<<"enter the price of washing machine:";
cin>>price_wash_machine;
cout<<"enter the unit price of each toy:";
cin>>toy_price;
double saved_money=0.0, money_recieved=0.0;
for(int i=1;i<=age;i++)
{
    if(i%2==0){
    money_recieved+=10;
    saved_money+=money_recieved - 1;
    }
else{
    toys++;
}}
saved_money+=toys*toy_price;
if(saved_money>=price_wash_machine){
    cout<<"yes!"<< fixed<<setprecision(0)<<saved_money-price_wash_machine<<endl;
}
else{
    cout<<"no!"<<fixed<<setprecision(0)<<price_wash_machine-saved_money<<endl;
}
return 0;
}